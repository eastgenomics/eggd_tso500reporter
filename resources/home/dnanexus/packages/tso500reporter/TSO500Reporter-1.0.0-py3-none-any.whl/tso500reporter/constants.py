"""
Constants for use by module
"""
MSI_FIELDS = ["Usable MSI Sites",
        "Total MSI Sites Unstable",
        "Percent Unstable MSI Sites"]
TMB_FIELDS = ["Total TMB",
        "Coding Region Size in Megabases",
        "Number of Passing Eligible Variants"]
